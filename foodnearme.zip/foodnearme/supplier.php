<?php
require('db.inc.php');
require('top.inc.php');
if(!isset($_SESSION['AUTH'])){
    session_destroy();
    header('location:supplieraction');
        die();
}
$who=$_SESSION['AUTH'];
$res=mysqli_query($con, "select * from supplier where id='$who'");
if($_SERVER["REQUEST_METHOD"] == "POST"){
    if (isset( $_POST['savelogout'])) {
        $password=$_POST['password'];
        $title=$_POST['title'];
        $servesin=$_POST['servesin'];
        $descrip=$_POST['descrip'];
        $pricepday=$_POST['pricepday'];
        $pricemonth=$_POST['pricemonth'];
        $type=$_POST['type'];
        $suptype=$_POST['suptype'];
        $servtype=0;
        if(isset($_POST['servtype']))
            $servtype=1;
        if(isset($_FILES['thumbn'])) {
            //($_POST);
            $img_name = $_FILES['thumbn']['name'];
            $img_size = $_FILES['thumbn']['size'];
            $tmp_name = $_FILES['thumbn']['tmp_name'];
            $error = $_FILES['thumbn']['error'];
            if($error == 0){
                if($img_size  > 125000){
                    echo "<script>alert('FILE SIZE TOO LARGE')</script>";
                }
                else{
                    $img_ex = pathinfo($img_name, PATHINFO_EXTENSION);
                    $img_ex_lc = strtolower($img_ex);
                    $allowed_exs = array("jpg", "jpeg", "png");
                    if(in_array($img_ex_lc, $allowed_exs)){
                        $new_img_name = uniqid("IMG-", true).'.'.$img_ex_lc;
                        $img_upload_path = 'uploads/'.$new_img_name;
                        move_uploaded_file($tmp_name, $img_upload_path);
                        $sql="update supplier set password='$password',image='$new_img_name',title='$title',servesin='$servesin',".
                        "descrip='$descrip',pricepday='$pricepday',pricemonth='$pricemonth',type='$type',suptype='$suptype',".
                        "servtype='$servtype' where id='$who'";
                        mysqli_query($con,$sql);
                        echo "<script>alert('Uploaded Successfully')</script>";
                    }
                    else{
                        echo "<script>alert('CHOOSEN FILE TYPE NOT ALLOWED')</script>";
                    }
                }
            }
        }
        else{
            $sql="update supplier set password='$password',title='$title',servesin='$servesin',".
                "descrip='$descrip',pricepday='$pricepday',pricemonth='$pricemonth',type='$type',suptype='$suptype',".
                "servtype='$servtype' where id='$who'";
            mysqli_query($con,$sql);
            echo "<script>alert('Uploaded Successfully')</script>";
        }
        mysqli_close($con);
        session_destroy();
        header('location:supplieraction');
        die();
    }
}
?>

<body>
    <nav class="navbar" style="height:50px;background-color:purple;">
    </nav>
    <div class="d-flex justify-content-center" id="SupDfle">
        <form method="POST" id="SupForm" enctype="multipart/form-data">
            <div class="Supdata">
                <center>
                    <h4>My Profile</h4>
                </center>
                <?php
            while($row=mysqli_fetch_assoc($res)){?>
                <label for="phone" class="fiLabel">Phone: <?php echo $row['phone'];?></label><br>
                <label for="password" class="fiLabel">Password: <?php echo $row['password'];?></label><br>
                <input type="password" name="password" id="password" value="<?php echo $row['password'];?>"
                    placeholder="Password(Max: 10 chars)" maxlength="10" required><br><br>
                <?php if($row['image']==''){
                        echo "<label for='thumbn' style='color:green;'class='fiLabel'>Food Image(Can not be changed in future)</label>".
                        " <input type='file' name='thumbn' id='thumbn' required><br><br>";
                    }
                    else{
                        echo "<label style='color:green;' class='fiLabel'>Food Image Already Uploaded</label>";
                    }
                ?>
                <br><label for="title" class="fiLabel">Title:</label><br>
                <input type="title" name="title" id="title" placeholder="Title" value="<?php echo $row['title'];?>"
                    maxlength="50" required><br><br>
                <label for="thumbn" class="fiLabel">Service Areas Comma-Seperated:</label><br>
                <input name="servesin" rows="4" style="width:100%" maxlength="120"
                    value="<?php echo $row['servesin'];?>" placeholder="Agra,Mathura,New-Delhi" required>
                </input><br>
                <label for="descrip" class="fiLabel">Description of Service:</label><br>
                <input name="descrip" rows="4" style="width:100%" maxlength="200" value="<?php echo $row['descrip'];?>"
                    placeholder="Morning: Chana with tea...." required>
                </input><br><br>
                <label for="descrip" class="fiLabel">Choose Supplier Type:</label><br>
                <?php if($row['suptype']=="1"){?>
                <input type="radio" name="suptype" value="2">Tiffin Service
                <input type="radio" name="suptype" value="1" checked>Local Vendor
                <input type="radio" name="suptype" value="3">Restraunt
                <?php }else if($row['suptype']=="2"){?>
                <input type="radio" name="suptype" value="2" checked>Tiffin Service
                <input type="radio" name="suptype" value="1">Local Vendor
                <input type="radio" name="suptype" value="3">Restraunt
                <?php }else{?>
                <input type="radio" name="suptype" value="2">Tiffin Service
                <input type="radio" name="suptype" value="1">Local Vendor
                <input type="radio" name="suptype" value="3" checked>Restraunt
                <?php }?>
                <br>
                <label for="descrip" class="fiLabel">Choose Delivery:</label><br>
                <input type="checkbox" name="servtype" <?php if($row['servtype']=="1") echo "checked";?>>Delivery Available<br>
                <label for="pricepday" class="fiLabel">Price per day:</label><br>
                <input type="number" name="pricepday" id="pricepday" min="0" value="<?php echo $row['pricepday'];?>"
                    max="10000" required><br>
                <label for="pricemonth" class="fiLabel">Price per month:</label><br>
                <input type="number" name="pricemonth" id="pricemonth" value="<?php echo $row['pricemonth'];?>" min="0"
                    max="10000" required><br><br>
                <label for="typ">Type:</label>
                <select name="type" id="type">
                    <?php if($row['type']=="1"){?>
                    <option value="1" selected>Veg</option>
                    <option value="2">Non-Veg</option>
                    <?php }else{?>
                    <option value="1">Veg</option>
                    <option value="2" selected>Non-Veg</option>
                    <?php }?>
                </select><br><br>
                <button type="submit" style="background-color:green;color:white;" name="savelogout">
                    <i class="fas fa-external-link-alt"></i> Save and Log Out</button>
                <?php }?>
            </div>
        </form>
    </div>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous">
    </script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
    -->
</body>
<footer style="background-color:purple;color:white;text-align:center;height:90px;">
    &#169;Harshvardhan Singh
    <br>For any query, mail us at<br>
    query_foodnearr@gmail.com
</footer>

</html>