function next(){
document.getElementById('log').style.display = "none";
document.getElementById('regis').style.display = "block";
}
function prev(){
document.getElementById('regis').style.display = "none";
document.getElementById('log').style.display = "block";
}
