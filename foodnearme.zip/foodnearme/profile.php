<?php
require('db.inc.php');
require('top.inc.php');
if(!isset($_GET['glpw'])){
    header('location:index');
        die();
}
$who=$_GET['glpw'];
$res=mysqli_query($con, "select * from supplier where id='$who'");
?>

<body>
    <nav class="navbar" style="height:50px;background-color:purple;">
    </nav>
    <?php
    $count = mysqli_num_rows($res);
    if($count==0){
        echo "<h5 style='margin-bottom:500px;color:red;text-align:center;margin-top:30px;'>Don't change the Link</h5>";
    }
    else{
        $row=mysqli_fetch_assoc($res);?>
    <div class="card mx-auto my-auto" style="width: 20rem;">
        <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="uploads/<?php echo $row['image'];?>" class="d-block w-100" alt="..." height="auto"
                        width="auto">
                </div>
            </div>
        </div>

    </div>

    <div class="card mx-auto my-auto p-2 mb-3" style="width: 20rem;justify-content:center;">
        <div class="card-body">
            <p class="card-title"><?php echo $row['title'];?></p>

            <h6 style='color:green'>&#8226;Price/Day: <?php echo "Rs. ".$row['pricepday'];?></h6>
            <h6 style='color:#8A2BE2'>&#8226;Price(Month): <?php echo "Rs. ".$row['pricemonth'];?></h6>
            <h6 style='color:#C71585'>&#8226;Type: <?php 
                                    if($row['type']=='1') echo "Vegetarian";
                                    else echo "Non-Vegetarian";
                                ?></h6>
            <h6 style='color:#66CDAA'>&#8226;Description:<br><?php echo $row['descrip'];?></h6>
            <h6 style='color:#8B008B'>&#8226;Available at:<br><?php echo $row['servesin'];?></h6>
            <h6 style='color:black;'>&#8226;Phone: <?php echo $row['phone'];?></h6>
            <div style="text-align: center;text-align:center;animation:2s blinker linear infinite;-webkit-animation:1s blinker linear infinite;
                -moz-animation:1s blinker linear infinite;color: red;">
                <a href="https://wa.me/+91<?php echo $row['phone']?>"><img src="assets/whatsapp.png" alt="Error"
                        style="width:43px;height:44px;"></a>
                <input type="submit" style="font-size:13px;color:white;background-color:green;"
                    value="Ask On WhatsApp" onclick="location.href='https://wa.me/+91<?php echo $row['phone']?>';"
                    class="btn btn-primary border btn-3">
            </div>
        </div>
    </div>
    <?php }?>


    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous">
    </script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
    -->
</body>
<footer style="background-color:purple;color:white;text-align:center;height:90px;">
    &#169;Harshvardhan Singh
    <br>For any query, mail us at<br>
    query_foodnearr@gmail.com
</footer>

</html>