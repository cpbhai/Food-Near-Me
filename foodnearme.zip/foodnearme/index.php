<?php
require('db.inc.php');
$query=false;
$noResult=false;
if($_SERVER["REQUEST_METHOD"] == "POST"){
  if (isset( $_POST['search'])) {
    echo "<script>refSearch()</script>";
    $query=true;
    $data=$_POST['query'];
    $suptype=$_POST['suptype'];
    $servtype=0;
    if(isset($_POST['servtype']))
        $servtype=1;
    $sql="SELECT * FROM supplier WHERE servtype='$servtype' and suptype='$suptype' and servesin LIKE '%$data%';";
    $res = mysqli_query($con, $sql);
    $count = mysqli_num_rows($res);
		if($count==0){
      $noResult=true;
    }
  }
}
?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
        integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <!--link rel="shortcut icon" href="image/download/management/static/vector-logo-school-260nw-427910128.jpg"
        type="image/x-icon"-->
    <script src="js/script.js"></script>
    <title>Food Near Me</title>
    <!--script>
    document.onkeydown = function (e) {
      if (event.keyCode == 123) {
        return false;
      }
      if (e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) {
        return false;
      }
      if (e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)) {
        return false;
      }
      if (e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) {
        return false;
      }
    }
  </script-->
</head>

<body oncontextmenu="return false;">
    <nav class="navbar" style="height:50px;background-color:purple;">
        <div class="custom" style="padding: 0px 0px 0px 5px;">
            <a href="supplieraction"
                style="cursor:pointer;background-color: blue;color:white;text-decoration: none;padding: 7px 20px;font-weight:bold;">
                Supplier ?</a>
        </div>
    </nav>
    <div class="cont" style="margin-left:auto;margin-right:auto;">
        <marquee width="100%" direction="left" height="58px" scrollamount="10">
            <h1 style="font-family: 'Pacifico', cursive;color:#FF4500;"><b>
                    Search food near you
                </b></h1>
        </marquee>
    </div>
    <div class="IndexSearch" id="refSearch" style="margin-top:40px;">
        <form method="POST" style="text-align:center;">
            <div class="md-form active-cyan active-cyan-2 mb-3" style="padding: 0px 5px 0px;">
                <input class="form-control" type="text" name="query" placeholder="Location near you, Like: Kamla Nagar"
                    aria-label="Search" required>
            </div>
            <input type="radio" name="suptype" value="2">Tiffin Service
            <input type="radio" name="suptype" value="1" checked>Local Vendor
            <input type="radio" name="suptype" value="3">Restraunt
            <br>
            <input type="checkbox" name="servtype">Delivery Available<br><br>
            <button style="position:relative;width:60%;" type="submit" name="search"
                class="btn btn-success">Submit</button>
        </form>
    </div><br>
    <?php
    if($query){?>
    <?php if($noResult){?>
    <h5 style='color:red;text-align:center;margin-top:10px;'>
        <i class="far fa-sad-tear"></i> Sorry, No Matching Data
    </h5>
    <?php }?>
    <div id='products' class="col-lg-10  mx-auto">
        <div class="row mx-auto " style="justify-content:center;">
            <?php
            while($row=mysqli_fetch_assoc($res)){?>
            <div class="card p-1 mb-2" style="width: 9.8rem;">
                <img class="card-img-top" src="uploads/<?php echo $row['image'];?>" alt="Card image cap">
                <div class="card-body">
                    <p class="card-title"><?php echo $row['title'];?></p>

                    <h6 style='color:green'>&#8226;Price/Day:<br><?php echo "Rs. ".$row['pricepday'];?></h6>
                    <h6 style='color:#8A2BE2'>&#8226;Price(Month): <br><?php echo "Rs. ".$row['pricemonth'];?></h6>
                    <h6 style='color:#C71585'>&#8226;Type:<br><?php 
                                    if($row['type']=='1') echo "Vegetarian";
                                    else echo "Non-Vegetarian";
                                ?></h6>
                    <h6 style='color:#8B008B'>&#8226;Available at:<br><?php echo $row['servesin'];?></h6>
                    <a href="profile?glpw=<?php echo $row['id']?>" target="_blank" class="btn stretched-link"></a>
                </div>
            </div>
            <?php }?>
        </div>
    </div>
    <?php }?>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous">
    </script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
    -->
</body>
<footer style="<?php if(!isset($_POST['search'])||$noResult) echo "margin-top:215px;";?>
;background-color:purple;color:white;text-align:center;height:90px;">
    &#169;Harshvardhan Singh
    <br>For any query, mail us at<br>
    query_foodnearr@gmail.com
</footer>

</html>