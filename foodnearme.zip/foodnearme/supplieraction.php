<?php
require('db.inc.php');
if($_SERVER["REQUEST_METHOD"] == "POST"){
	$phone = mysqli_real_escape_string($con, $_POST['phone']);
	$password = mysqli_real_escape_string($con, $_POST['password']);
	if(isset($_POST['reg'])){
		$res = mysqli_query($con, "select * from supplier where phone='$phone'");
		$count = mysqli_num_rows($res);
		if($count>0){
			echo "<script>alert('Already Registered!')</script>";
		}
		else{
			$sql="insert into supplier(phone,password,image,title,servesin,descrip,pricepday,pricemonth,type,suptype,servtype)".
			" values('$phone','$password','','','','','','',1,1,0)";
			mysqli_query($con, $sql);
			echo "<script>alert('Registered Successfully, Now, Log In')</script>";
		}
	}
	else if(isset($_POST['log'])){
		$res = mysqli_query($con, "select * from supplier where phone='$phone' and password='$password'");
		$count = mysqli_num_rows($res);
		if($count>0){
            if(isset($_SESSION['AUTH'])){
                if(true){
                    $_SESSION['logg']=1;
                    header('location:supplieraction');
                    die();
                }
            }
            else{
                while($row=mysqli_fetch_assoc($res)){
                    $_SESSION['AUTH']=$row['id'];
                }
                header('location:supplier');
                die();
            }
        }
		else{
			echo "<script>alert('Wrong Details')</script>";
		}
	}
}
?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
        integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <!--link rel="shortcut icon" href="image/download/management/static/vector-logo-school-260nw-427910128.jpg"    type="image/x-icon"-->
    <style>
    .regis {
        display: none;
        width: 300px;
        height: 345px;
        border-radius: 5px;
        padding: 5px;
        margin: 10px;
        box-shadow: 2px 2px 8px 5px grey;
    }

    .log {
        display: block;
        width: 300px;
        height: 345px;
        border-radius: 5px;
        padding: 5px;
        margin: 10px;
        box-shadow: 2px 2px 8px 5px grey;
    }

    div#dfle {
        text-align: center;
        margin-bottom: 120px;
        margin-top: 50px;
    }
    </style>
    <script>
    function next() {
        document.getElementById('log').style.display = "none";
        document.getElementById('regis').style.display = "block";
    }

    function prev() {
        document.getElementById('regis').style.display = "none";
        document.getElementById('log').style.display = "block";
    }

    function onlyNumberKey(evt) {

        // Only ASCII character in that range allowed
        var ASCIICode = (evt.which) ? evt.which : evt.keyCode
        if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
            return false;
        return true;
    }
    </script>
    <title>Food Near Me</title>
</head>

<body>
<nav class="navbar" style="height:50px;background-color:purple;">
        <div class="custom" style="padding: 0px 0px 0px 44%;">
            <a href="index"
                style="cursor:pointer;background-color: blue;color:white;text-decoration: none;padding: 7px 20px;font-weight:bold;">
                Go to Home Page</a>
        </div>
    </nav>
    <div class="d-flex justify-content-center" id="dfle">
        <form method="POST" id="logsign">
            <div class="log" id="log">
                <center>
                    <h4>Login Here</h4>
                </center>
                <input type="phone" onkeypress="return onlyNumberKey(event)" name="phone" id="phone" minlength="10"
                    maxlength="10" placeholder="Phone" required><br><br>
                <input type="password" name="password" id="password" placeholder="Password"
                    maxlength="10" required><br><br>
                <button type="submit" style="background-color:green;color:white;" name="log"><i
                        class="fa fa-sign-in-alt" aria-hidden="true"></i>
                    Login</button>
                <a style="cursor:pointer;background-color: blue;color:white;text-decoration: none;padding: 7px 10px;margin-left:35px;"
                    onclick="next()">
                    <i class="fas fa-user-plus"></i> Join</a><br><br>
                    <?php
                    if(isset($_SESSION['logg'])){
                        echo "<h6 style='color:red;'>You were already logged in.<br>We logged you out.<br>Please Login Again!</h6>";
                        session_destroy();
                    }
                    ?>
            </div>
        </form>
        <form method="POST" id="logsign">

            <div class="regis" id="regis">
                <center>
                    <h4>New Account</h4>
                </center>
                <input type="phone" onkeypress="return onlyNumberKey(event)" name="phone" id="phone" minlength="10"
                    maxlength="10" placeholder="Phone" required><br><br>
                <input type="password" name="password" id="password" placeholder="Password(Max: 10 chars)"
                    maxlength="10" required><br><br>
                <button type="submit" style="background-color:green;color:white;" name="reg">
                <i class="fas fa-user-plus"></i> Join Me<br>
                </button>
                <a style="cursor:pointer;background-color: blue;color:white;text-decoration: none;padding: 7px 12px;margin-left:18px;"
                    onclick="prev()">
                    <i class="fa fa-sign-in-alt" aria-hidden="true"></i> Already User</a>
            </div>
        </form>
    </div>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous">
    </script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
    -->
</body>
<footer style="background-color:purple;color:white;text-align:center;height:90px;">
    &#169;Harshvardhan Singh
    <br>For any query, mail us at<br>
    query_foodnearr@gmail.com
</footer>

</html>