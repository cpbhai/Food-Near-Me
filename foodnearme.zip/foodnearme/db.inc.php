<?php
session_start();
$con = mysqli_connect('localhost', 'root', '', 'daily_food');
?>